package com.centrychat.android

import android.app.Application
import android.util.Log
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.network.BootDiagnostics

/**
 * The CentryChat Android application class.
 *
 * Acts as the host for app-wide singletons via [AppContainer]. Everything
 * that needs to live as long as the process (OkHttp client, Retrofit, the
 * session store, the auth repository) is constructed once here and exposed
 * to the rest of the app through the container.
 *
 * WHY A CUSTOM APPLICATION CLASS?
 *  - Compose ViewModels obtain their dependencies through a ViewModelProvider
 *    Factory. The factory reads from [AppContainer].
 *  - Dependency injection is intentionally manual (no Hilt/Koin) — keeps
 *    the dependency surface small + the build fast.
 *
 * CRASH-SAFETY (Root Cause #2 fix):
 *  - The previous version eagerly triggered the lazy `appContainer` init
 *    inside onCreate() — which constructed `PersistentCookieJar` (which
 *    called `loadFromDisk()` synchronously → forced EncryptedSharedPreferences
 *    init on the main thread). On devices with a flaky keystore this threw
 *    GeneralSecurityException → killed the process → black screen + crash.
 *  - The fix: do NOT eagerly trigger the container. Let it lazily initialize
 *    on first access from the UI layer (which happens on the main thread
 *    but only after the activity is created). The cookie jar + secure
 *    session store are themselves lazy now, so even if they fail, the
 *    failure is contained (logged + falls back) rather than crashing
 *    the process.
 */
class CentryChatApp : Application() {

    /**
     * Lazily-initialized container. The lazy block guarantees thread-safe
     * construction (Kotlin's default `LazyThreadSafetyMode.SYNCHRONIZED`)
     * even if multiple threads reach into [appContainer] at the same time
     * during the first cold start.
     */
    val appContainer: AppContainer by lazy {
        try {
            AppContainer(this)
        } catch (e: Exception) {
            // CRITICAL: never let this propagate. Application.onCreate() is
            // the last line of defense — if it throws, the process dies.
            // Log + rethrow as IllegalStateException so the developer sees
            // the failure clearly (the alternative — silently returning a
            // broken container — would just defer the crash).
            Log.e("CentryChat/App", "AppContainer init failed", e)
            throw e
        }
    }

    override fun onCreate() {
        super.onCreate()
        // Intentionally do NOT eagerly trigger appContainer here — let it
        // initialize lazily on first access (from MainActivity.setContent).
        // The container's components (cookieJar, secureSessionStore) are
        // themselves lazy, so even first access is safe + non-throwing.

        // ── Boot diagnostics ───────────────────────────────────────────
        // Runs ONCE on cold-start (debug builds only) and writes a clear
        // summary to Logcat under the `CentryChat/Boot` tag: which backend
        // URL the APK was built with + whether that backend is reachable
        // from this device. Helps diagnose any future "HTTP 404" report
        // in 3 seconds instead of guessing.
        //
        // The probe is fire-and-forget on a background scope; it never
        // blocks the UI thread and never throws into onCreate(). The
        // container is lazily initialized here (touching .appContainer
        // for the first time) — if the keystore fails, the container's
        // own try/catch logs it and the BootDiagnostics probe is skipped.
        //
        // RELEASE BUILDS: BootDiagnostics.runOnce is a no-op when
        // BuildConfig.DEBUG == false, so release builds pay zero cost
        // and leak zero diagnostic information to anyone running
        // `adb logcat` on a stolen device.
        try {
            BootDiagnostics.runOnce(appContainer.appScope, appContainer.okHttpClient)
        } catch (e: Exception) {
            // Non-fatal — never let boot diagnostics crash the app.
            Log.w("CentryChat/App", "BootDiagnostics skipped: ${e.message}")
        }
    }
}
