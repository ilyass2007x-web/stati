package com.centrychat.android.core.network

import com.centrychat.android.BuildConfig
import okhttp3.Interceptor
import okhttp3.Response

/**
 * Adds the `Origin` header to every state-changing request (POST/PUT/PATCH/DELETE).
 *
 * WHY: the CentryChat backend's CSRF protection (`src/lib/security/csrf.ts`)
 * compares the request's `Origin` header against the deployment URL. Browser
 * requests automatically include `Origin`, but OkHttp does NOT — so the Android
 * client has to add it explicitly. Without this header, every POST/PUT/PATCH/
 * DELETE call would be rejected with HTTP 403 ("CSRF_CHECK_FAILED").
 *
 * The header value matches the configured production API URL (BuildConfig.API_ORIGIN)
 * so the backend's sameOrigin check passes.
 *
 * For GET/HEAD/OPTIONS requests, the Origin header is omitted — these methods
 * are exempt from CSRF checks + adding an unnecessary header would just inflate
 * the request size.
 */
class AuthInterceptor(
    private val cookieJar: PersistentCookieJar,
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val builder = request.newBuilder()

        // Add the Origin header on state-changing methods so the backend's
        // CSRF protection accepts the request.
        val method = request.method.uppercase()
        if (method == "POST" || method == "PUT" || method == "PATCH" || method == "DELETE") {
            builder.header("Origin", BuildConfig.API_ORIGIN)
            // Some CSRF implementations prefer Referer as a fallback. We add
            // it as a defense-in-depth — the backend tries Origin first, and
            // only falls back to Referer if Origin is missing.
            builder.header("Referer", BuildConfig.API_ORIGIN + "/")
        }

        // The cookieJar installed on the OkHttp client will add the Cookie
        // header automatically for matching URLs (since we route all
        // requests through the same client). We don't need to manually
        // attach the session cookie here.

        return chain.proceed(builder.build())
    }
}
