package com.centrychat.android.core.network

import com.centrychat.android.BuildConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import android.util.Log
import java.io.IOException

/**
 * Lightweight, **safe** boot-time diagnostics.
 *
 * Runs ONCE per cold-start (in debug builds only) and writes a clear
 * summary to Logcat under the `CentryChat/Boot` tag. The summary tells
 * the developer/user EXACTLY which backend URL the APK was built with
 * and whether that backend is reachable from the device — so any future
 * "HTTP 404" complaint can be diagnosed within 3 seconds of opening
 * Logcat instead of guessing.
 *
 * WHAT IS LOGGED (safe — never sensitive):
 *   - BuildConfig.DEBUG, versionCode, versionName
 *   - BuildConfig.API_BASE_URL  (the public production URL — not a secret)
 *   - BuildConfig.API_ORIGIN    (the public production URL — not a secret)
 *   - A single GET /api/v1/health probe:
 *       • HTTP method + URL
 *       • HTTP status code
 *       • Round-trip milliseconds
 *       • First 80 chars of the body (the backend's health JSON — not sensitive)
 *
 * WHAT IS NEVER LOGGED:
 *   - Passwords (never present on /api/v1/health — it's unauthenticated)
 *   - Cookies (the probe is unauthenticated — no Cookie header is sent)
 *   - Authorization headers
 *   - The user's email / PII
 *
 * RELEASE BUILDS: this entire class is a no-op. The `runOnce` method
 * is gated on `BuildConfig.DEBUG` and the call site in
 * [com.centrychat.android.CentryChatApp] is also gated — so release
 * builds pay zero cost and leak zero diagnostic information.
 *
 * USAGE FROM LOGCAT:
 *   adb logcat -s CentryChat/Boot
 *
 * EXPECTED OUTPUT (when everything is working):
 *   CentryChat/Boot: ╔══════════════════════════════════════════════╗
 *   CentryChat/Boot: ║  CentryChat boot diagnostics                   ║
 *   CentryChat/Boot: ╚══════════════════════════════════════════════╝
 *   CentryChat/Boot: Build       : DEBUG=true v1.0 (1)
 *   CentryChat/Boot: API_BASE_URL= https://sentrychat.netlify.app
 *   CentryChat/Boot: API_ORIGIN  = https://sentrychat.netlify.app
 *   CentryChat/Boot: Probe → GET https://sentrychat.netlify.app/api/v1/health
 *   CentryChat/Boot: Probe ← 200 OK (84 ms) body= {"status":"ok",...
 *   CentryChat/Boot: Backend reachable ✅ — auth endpoints will work.
 *
 * EXPECTED OUTPUT (when the URL is wrong — the original 404 bug):
 *   CentryChat/Boot: Probe ← 404 Not Found (52 ms) body= Not Found - Request ID...
 *   CentryChat/Boot: Backend NOT reachable ❌ — HTTP 404 means API_BASE_URL is wrong.
 *   CentryChat/Boot: Check app/build.gradle.kts — the URL must point to the
 *   CentryChat/Boot: real CentryChat backend (currently https://sentrychat.netlify.app).
 */
object BootDiagnostics {

    private const val TAG = "CentryChat/Boot"

    /** Run the diagnostics once. Safe to call from any thread; runs in
     *  the provided [scope] on [Dispatchers.IO]. No-op in release builds. */
    fun runOnce(scope: CoroutineScope, client: OkHttpClient) {
        // RELEASE GUARD: the diagnostic block below writes the API URL to
        // Logcat. The URL itself is public (it's the production deployment
        // URL — no secret), but in release builds we want zero diagnostic
        // noise + zero chance of leaking build configuration to anyone
        // running `adb logcat` on a stolen device. Debug builds only.
        if (!BuildConfig.DEBUG) return

        scope.launch(Dispatchers.IO) {
            val baseUrl = BuildConfig.API_BASE_URL
            val origin = BuildConfig.API_ORIGIN

            Log.i(TAG, "╔══════════════════════════════════════════════╗")
            Log.i(TAG, "║  CentryChat boot diagnostics                   ║")
            Log.i(TAG, "╚══════════════════════════════════════════════╝")
            Log.i(TAG, "Build       : DEBUG=${BuildConfig.DEBUG} v${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
            Log.i(TAG, "API_BASE_URL= $baseUrl")
            Log.i(TAG, "API_ORIGIN  = $origin")

            // Build the probe URL: <baseUrl>/api/v1/health
            // The health endpoint is unauthenticated + returns a small JSON
            // blob with status + uptime + timestamp. No cookies, no auth,
            // no PII — ideal for a connectivity probe.
            val probeUrl = baseUrl.trimEnd('/') + "/api/v1/health"
            Log.i(TAG, "Probe → GET $probeUrl")

            val request = Request.Builder()
                .url(probeUrl)
                .get()
                .header("Accept", "application/json")
                .build()

            val started = System.nanoTime()
            try {
                client.newCall(request).execute().use { resp ->
                    val elapsedMs = (System.nanoTime() - started) / 1_000_000
                    val code = resp.code
                    val body = try {
                        resp.body?.string()?.take(80)?.replace('\n', ' ')
                    } catch (_: Exception) {
                        "<unparseable>"
                    }
                    Log.i(TAG, "Probe ← $code ${resp.message} ($elapsedMs ms) body= $body")

                    when (code) {
                        in 200..299 -> Log.i(TAG, "Backend reachable ✅ — auth endpoints will work.")
                        404 -> {
                            Log.w(TAG, "Backend NOT reachable ❌ — HTTP 404 means API_BASE_URL is wrong.")
                            Log.w(TAG, "Check app/build.gradle.kts — the URL must point to the")
                            Log.w(TAG, "real CentryChat backend (currently https://sentrychat.netlify.app).")
                        }
                        403 -> {
                            Log.w(TAG, "Backend reachable but probe blocked by CSRF (HTTP 403).")
                            Log.w(TAG, "This is unexpected for a GET — check API_ORIGIN matches API_BASE_URL.")
                        }
                        in 500..599 -> Log.w(TAG, "Backend reachable but returned a server error ($code). Try again later.")
                        else -> Log.w(TAG, "Backend reachable but returned an unexpected status ($code).")
                    }
                }
            } catch (e: IOException) {
                val elapsedMs = (System.nanoTime() - started) / 1_000_000
                Log.w(TAG, "Probe ← IOException ($elapsedMs ms): ${e.javaClass.simpleName}: ${e.message}")
                Log.w(TAG, "Could not reach the backend. Check internet connectivity, DNS,")
                Log.w(TAG, "and that the device's clock is correct (SSL requires accurate time).")
            } catch (e: Exception) {
                val elapsedMs = (System.nanoTime() - started) / 1_000_000
                Log.w(TAG, "Probe ← ${e.javaClass.simpleName} ($elapsedMs ms): ${e.message}")
            }
        }
    }
}
