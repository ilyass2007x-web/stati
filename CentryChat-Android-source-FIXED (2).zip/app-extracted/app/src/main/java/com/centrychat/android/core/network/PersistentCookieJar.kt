package com.centrychat.android.core.network

import android.content.Context
import com.centrychat.android.core.storage.SecureSessionStore
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import org.json.JSONArray
import org.json.JSONObject

/**
 * A persistent [CookieJar] that stores cookies in encrypted SharedPreferences.
 *
 * The CentryChat backend uses iron-session cookies for authentication (cookie
 * name: `messenger_session`). The cookie is:
 *   - HttpOnly (browsers hide it from JavaScript; for OkHttp we just need
 *     to store the raw value and re-send it).
 *   - SameSite=Lax (OkHttp doesn't enforce SameSite — the app is responsible
 *     for not leaking the cookie to cross-origin requests, which it never does
 *     because every request goes to the configured production URL).
 *   - Secure (only sent over HTTPS — OkHttp won't send cookies to HTTP URLs
 *     unless explicitly configured).
 *
 * STORAGE FORMAT
 *  - We persist cookies as a small JSON map keyed by the cookie name (the
 *    session cookie is the only one we expect to see, but we store any
 *    cookie the server sets — future-proof for analytics / theme cookies).
 *  - The map is JSON-serialized + written to [SecureSessionStore]. The
 *    store uses AndroidX Security's EncryptedSharedPreferences (AES-GCM
 *    256-bit), so the cookie value is encrypted at rest.
 *
 * EXPIRY HANDLING
 *  - Each cookie stores its [Cookie.expiresAt] timestamp. On load, we
 *    filter out expired cookies so we never send a cookie the server has
 *    already invalidated.
 *  - The CentryChat session cookie has a 7-day TTL — after that, the
 *    backend returns HTTP 401, which the [UnauthorizedInterceptor] catches
 *    + clears the local session store.
 */
class PersistentCookieJar(
    context: Context,
) : CookieJar {

    private val store: SecureSessionStore = SecureSessionStore(context)

    /** In-memory cache of cookies for the current URL. Loaded once on first
     *  use, kept in sync with the persistent store on every save.
     *
     *  CRASH-SAFETY (Root Cause #2 fix): the previous version called
     *  `loadFromDisk()` in the constructor, which forced EncryptedSharedPreferences
     *  initialization on the main thread during Application.onCreate(). If the
     *  keystore was unavailable, this threw + killed the process. The load is
     *  now lazy (only happens on first actual use, not at construction) + any
     *  failure is logged + results in an empty cache (no crash). */
    private val cache: MutableMap<String, Cookie> by lazy {
        try {
            loadFromDisk().toMutableMap()
        } catch (e: Exception) {
            android.util.Log.w("CentryChat/CookieJar", "loadFromDisk failed (non-fatal): ${e.message}")
            mutableMapOf()
        }
    }

    @Synchronized
    override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
        for (cookie in cookies) {
            // Persist only session-scoped cookies. We don't need to keep
            // short-lived analytics cookies — they'd just bloat the store.
            if (cookie.persistent && cookie.expiresAt > System.currentTimeMillis()) {
                cache[cookie.name] = cookie
            } else if (cookie.expiresAt <= 0L) {
                // Session cookie (no explicit expiry) — keep it for the
                // process lifetime + persist it (the server sets maxAge
                // via iron-session's ttl config: 7 days).
                cache[cookie.name] = cookie
            }
        }
        persistToDisk()
    }

    @Synchronized
    override fun loadForRequest(url: HttpUrl): List<Cookie> {
        val now = System.currentTimeMillis()
        return cache.values.filter { cookie ->
            cookie.matches(url) && (cookie.expiresAt == Long.MAX_VALUE || cookie.expiresAt > now)
        }
    }

    /** Clears the in-memory cache + the persistent store. Called on logout
     *  + when the backend returns HTTP 401. */
    @Synchronized
    fun clear() {
        cache.clear()
        store.clearSession()
    }

    /** Whether the session cookie is currently present. */
    @Synchronized
    fun hasSessionCookie(): Boolean {
        return cache[SESSION_COOKIE_NAME]?.let { cookie ->
            cookie.expiresAt == Long.MAX_VALUE || cookie.expiresAt > System.currentTimeMillis()
        } ?: false
    }

    // ── Persistence helpers ────────────────────────────────────────────

    private fun loadFromDisk(): Map<String, Cookie> {
        val raw = store.loadCookiesJson() ?: return emptyMap()
        return try {
            val array = JSONArray(raw)
            buildMap {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val cookie = obj.toCookie()
                    if (cookie != null) put(cookie.name, cookie)
                }
            }
        } catch (_: Exception) {
            // Corrupt JSON — drop the cache + start fresh.
            emptyMap()
        }
    }

    private fun persistToDisk() {
        val array = JSONArray()
        for (cookie in cache.values) {
            array.put(cookie.toJson())
        }
        store.saveCookiesJson(array.toString())
    }

    private fun Cookie.toJson(): JSONObject {
        return JSONObject().apply {
            put("name", name)
            put("value", value)
            put("expiresAt", expiresAt)
            put("domain", domain)
            put("path", path)
            put("secure", secure)
            put("httpOnly", httpOnly)
        }
    }

    private fun JSONObject.toCookie(): Cookie? {
        return try {
            val urlBuilder = HttpUrl.Builder()
                .scheme(if (optBoolean("secure", true)) "https" else "http")
                .host(optString("domain").removePrefix("."))
                .build()
            Cookie.Builder()
                .name(optString("name"))
                .value(optString("value"))
                .domain(optString("domain"))
                .path(optString("path", "/"))
                .expiresAt(optLong("expiresAt", Long.MAX_VALUE))
                .apply {
                    if (optBoolean("secure", true)) secure()
                    if (optBoolean("httpOnly", true)) httpOnly()
                }
                .build()
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        /** The cookie name used by the CentryChat backend's iron-session. */
        const val SESSION_COOKIE_NAME = "messenger_session"
    }
}
