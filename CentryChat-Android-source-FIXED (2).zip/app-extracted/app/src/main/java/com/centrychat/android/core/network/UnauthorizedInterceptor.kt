package com.centrychat.android.core.network

import android.content.Context
import com.centrychat.android.core.storage.SecureSessionStore
import com.centrychat.android.core.storage.SessionEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import okhttp3.Interceptor
import okhttp3.Response

/**
 * Detects HTTP 401 (Unauthorized) responses and broadcasts a [SessionEvent]
 * so the UI can react (typically: navigate to the login screen + show a toast).
 *
 * The interceptor is intentionally a NETWORK interceptor — it sees the real
 * response returned by the server, after any auth-relevant redirects. A
 * regular application interceptor would not catch 401s that get rewritten
 * by OkHttp's redirect handling.
 *
 * The interceptor does NOT retry the request or attempt any silent token
 * refresh — the CentryChat backend uses cookie-based sessions (iron-session)
 * with a 7-day TTL, and there is no refresh-token flow. When the session
 * expires, the user is simply redirected to log in again.
 */
class UnauthorizedInterceptor(
    private val sessionStore: SecureSessionStore,
    private val appScope: CoroutineScope,
) : Interceptor {

    /** Hot flow of session events (logout / expired). The UI subscribes to
     *  this in the root Composable and reacts. */
    private val _events: MutableSharedFlow<SessionEvent> = MutableSharedFlow(extraBufferCapacity = 4)
    val events: SharedFlow<SessionEvent> = _events.asSharedFlow()

    override fun intercept(chain: Interceptor.Chain): Response {
        val response = chain.proceed(chain.request())

        if (response.code == 401) {
            // The session cookie is no longer valid — clear the local
            // session store so subsequent app launches go straight to
            // the login screen instead of trying the expired cookie.
            appScope.launch {
                sessionStore.clearSession()
                _events.emit(SessionEvent.Expired)
            }
        }

        return response
    }
}
