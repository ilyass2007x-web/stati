package com.centrychat.android.core.storage

/**
 * Events emitted by the [com.centrychat.android.core.network.UnauthorizedInterceptor]
 * when the backend rejects a request with HTTP 401.
 *
 * The UI subscribes to this flow at the root level and reacts by navigating
 * the user back to the login screen + showing a toast explaining what
 * happened ("Your session has expired. Please sign in again.").
 *
 * This is intentionally a sealed class (not a Boolean) — it leaves room for
 * future event types (e.g. `LoggedOutRemotely`, `AccountSuspended`) without
 * breaking existing subscribers.
 */
sealed interface SessionEvent {
    /** The session cookie is no longer valid (server returned 401). */
    data object Expired : SessionEvent

    /** The user explicitly logged out from another device. (Reserved for
     *  future push-notification-based session revocation.) */
    data object LoggedOutRemotely : SessionEvent
}
