package com.centrychat.android.core.util

import java.util.concurrent.TimeUnit

/**
 * Time-formatting utilities for the feed + notifications + comments.
 *
 * All times from the backend are ISO-8601 UTC strings (e.g.
 * "2026-09-28T10:15:30.000Z"). We parse them to epoch-millis once + then
 * apply relative formatting (e.g. "5m", "2h", "3d", "2w") or absolute
 * formatting (e.g. "Sep 28, 2026") depending on the age.
 *
 * The relative format caps at "2w" — after that, we switch to absolute dates
 * (relative time beyond 2 weeks is no longer meaningful for social feeds).
 */
object TimeFormatter {

    /** Parse an ISO-8601 string to epoch millis. Returns 0 on parse error. */
    fun parse(iso: String?): Long {
        if (iso.isNullOrBlank()) return 0L
        return try {
            java.time.OffsetDateTime.parse(iso).toInstant().toEpochMilli()
        } catch (_: Exception) {
            try {
                java.time.LocalDateTime.parse(iso)
                    .atZone(java.time.ZoneOffset.UTC)
                    .toInstant()
                    .toEpochMilli()
            } catch (_: Exception) {
                0L
            }
        }
    }

    /** Returns a relative-time string ("just now", "5m", "2h", "3d", "2w"),
     *  or an absolute date string ("Sep 28, 2026") when older than 2 weeks. */
    fun relative(iso: String?, now: Long = System.currentTimeMillis()): String {
        val then = parse(iso)
        if (then == 0L) return ""
        val delta = now - then
        if (delta < 0) return "just now"

        val minutes = TimeUnit.MILLISECONDS.toMinutes(delta)
        val hours = TimeUnit.MILLISECONDS.toHours(delta)
        val days = TimeUnit.MILLISECONDS.toDays(delta)

        return when {
            minutes < 1 -> "just now"
            minutes < 60 -> "${minutes}m"
            hours < 24 -> "${hours}h"
            days < 7 -> "${days}d"
            days < 14 -> "${days / 7}w"
            else -> absolute(iso)
        }
    }

    /** Returns "Sep 28, 2026" format. */
    fun absolute(iso: String?): String {
        val then = parse(iso)
        if (then == 0L) return ""
        val instant = java.time.Instant.ofEpochMilli(then)
        val date = instant.atZone(java.time.ZoneOffset.UTC).toLocalDate()
        val formatter = java.time.format.DateTimeFormatter
            .ofPattern("MMM d, yyyy")
            .withLocale(java.util.Locale.ENGLISH)
        return date.format(formatter)
    }

    /** Returns "Sep 28, 2026 · 10:15 AM" format (used in article headers). */
    fun dateTime(iso: String?): String {
        val then = parse(iso)
        if (then == 0L) return ""
        val instant = java.time.Instant.ofEpochMilli(then)
        val zoned = instant.atZone(java.time.ZoneOffset.UTC)
        val formatter = java.time.format.DateTimeFormatter
            .ofPattern("MMM d, yyyy · HH:mm")
            .withLocale(java.util.Locale.ENGLISH)
        return zoned.format(formatter)
    }
}
