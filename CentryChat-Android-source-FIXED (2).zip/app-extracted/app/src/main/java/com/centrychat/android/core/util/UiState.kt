package com.centrychat.android.core.util

/**
 * Network-state + result wrappers used by all ViewModels.
 *
 * The app uses a sealed `UiState` instead of LiveData — Compose's
 * `collectAsState()` observes a `StateFlow<UiState<T>>` and recomposes
 * on every emission. The sealed hierarchy forces the UI to handle every
 * possible state (Loading, Success, Error, Empty) at compile time, which
 * eliminates the "stuck on loading" bug class.
 */

sealed interface UiState<out T> {
    /** Initial state — before the first load completes. */
    data object Loading : UiState<Nothing>

    /** Successful load. */
    data class Success<T>(val data: T) : UiState<T>

    /** Error state — typically network or server error. */
    data class Error(val message: String, val code: String? = null) : UiState<Nothing>

    /** Empty state — the request succeeded but returned no items. */
    data object Empty : UiState<Nothing>
}

/**
 * Pagination state for an infinite-scroll list.
 *
 * - [items] is the accumulated list of loaded items.
 * - [cursor] is the next-page cursor (null when there are no more items).
 * - [isLoading] is true during a load (first or subsequent).
 * - [isLoadingMore] is true ONLY during a load-more call (not the first page).
 * - [error] is set when the last request failed (null on success).
 */
data class PaginatedState<T>(
    val items: List<T> = emptyList(),
    val cursor: String? = null,
    val isLoading: Boolean = false,
    val isLoadingMore: Boolean = false,
    val error: String? = null,
    val endReached: Boolean = false,
) {
    val isEmpty: Boolean get() = items.isEmpty() && !isLoading && error == null
}
