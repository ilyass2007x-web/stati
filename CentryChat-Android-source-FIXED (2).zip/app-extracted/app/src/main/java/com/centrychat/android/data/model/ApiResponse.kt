package com.centrychat.android.data.model

import kotlinx.serialization.Serializable

/**
 * The backend's standard response envelope.
 *
 * Success: `{ "ok": true, "data": <payload> }`
 * Error:   `{ "ok": false, "error": { "message": "...", "code": "...", "detail": "..." } }`
 *
 * WHY A FLAT DATA CLASS (not a sealed class hierarchy):
 *  - The previous version modeled this as a `sealed class ApiResponse<out T>` with
 *    `Success<T>` and `Error` subclasses. Kotlinx-serialization treats sealed
 *    classes as POLYMORPHIC by default — it expects a discriminator field in
 *    the JSON (default name: `type`) so it knows which subclass to instantiate.
 *  - The CentryChat backend NEVER sends a `type` field — it discriminates
 *    success vs. error purely via the `ok` boolean. As a result, every
 *    successful login / signup / fetchUser call crashed at runtime with:
 *      `SerializationException: Class discriminator was missing and no
 *       default serializers were registered in the polymorphic scope of
 *       'ApiResponse'.`
 *  - Switching to a single flat data class with nullable `data` and `error`
 *    fields removes the polymorphism entirely. The JSON deserializes
 *    naturally:
 *       • `{"ok":true,"data":{...}}` → ApiResponse(ok=true, data={...}, error=null)
 *       • `{"ok":false,"error":{"message":"..."}}` → ApiResponse(ok=false, data=null, error={...})
 *    The [dataOrThrow] / [dataOrNull] / [errorMessage] extension functions
 *    use the `ok` boolean to decide which path to take — preserving the
 *    existing API surface for callers.
 *
 * GENERIC TYPE T:
 *  - `data: T?` is nullable. On error responses (ok=false), the backend
 *    omits `data` entirely — kotlinx-serialization sets it to null.
 *  - `error: ApiError?` is nullable. On success responses (ok=true), the
 *    backend omits `error` entirely — set to null.
 *  - The Retrofit kotlinx-serialization converter passes the reified type
 *    parameter T from the API method signature (e.g. `ApiResponse<LoginResponse>`)
 *    to the deserializer, so the `data` field is correctly typed as `LoginResponse`
 *    when present.
 *
 * WHAT ABOUT HTTP STATUS CODES?
 *  - For HTTP 200 + ok=true → ApiResponse.Success path (data returned).
 *  - For HTTP 200 + ok=false → application-level error (rare; the backend
 *    usually uses HTTP 4xx/5xx for errors).
 *  - For HTTP 4xx/5xx → Retrofit throws HttpException (handled in the
 *    repositories via the toApiException() extension, NOT here). The body
 *    of a 4xx/5xx response is the same `{"ok":false,"error":{...}}` shape
 *    and is accessible via `HttpException.response().errorBody()`.
 */
@Serializable
data class ApiResponse<T>(
    val ok: Boolean = false,
    val data: T? = null,
    val error: ApiError? = null,
)

/**
 * The structured error object embedded in `{"ok":false, "error": {...}}`.
 *
 * All fields except `message` are optional — the backend's `err()` helper
 * always sends `message` and conditionally sends `code`, `detail`, and
 * `suggestions` (e.g. for username-taken, the backend suggests alternatives).
 */
@Serializable
data class ApiError(
    val message: String,
    val code: String? = null,
    val detail: String? = null,
    val suggestions: List<String>? = null,
)

/**
 * A wrapper used by Retrofit for endpoints where we need to distinguish between
 * transport-level success/failure (HTTP status code) and application-level
 * success/failure (the `ok` field in the body).
 *
 * Most callers will use the [ApiResponse] extension functions instead.
 */
typealias HttpApiResponse<T> = retrofit2.Response<ApiResponse<T>>

/**
 * Returns the success data, or null if this is an error response (or if the
 * backend sent `ok=true` but no `data` field — an edge case that shouldn't
 * happen in practice but is handled defensively here).
 */
fun <T> ApiResponse<T>.dataOrNull(): T? = if (ok) data else null

/**
 * Returns the error message, or null if this is a success response.
 */
fun <T> ApiResponse<T>.errorMessage(): String? = error?.message

/**
 * Returns the success data, or throws an [ApiException] with the server's
 * error message if this is an error response. This is the primary entry
 * point used by the repositories — they call `response.dataOrThrow()`
 * and let any exception bubble up to the ViewModel's try/catch.
 *
 * EDGE CASE: if `ok=true` but `data` is null (which shouldn't happen with
 * the real backend, but could happen if a future maintainer changes the
 * response shape), we throw an ApiException with a generic message. This
 * is safer than returning null and letting the caller NPE later.
 */
fun <T> ApiResponse<T>.dataOrThrow(): T {
    if (ok && data != null) return data
    val msg = error?.message ?: if (ok) "Server returned success with no data." else "Request failed."
    throw ApiException(msg, error?.code)
}

/**
 * Exception thrown by [dataOrThrow] when the backend returns an error.
 * Carries the server's error message verbatim + the optional `code`
 * (e.g. `CSRF_CHECK_FAILED`, `RATE_LIMITED`) for programmatic handling.
 */
class ApiException(
    message: String,
    val code: String? = null,
) : Exception(message)

// ────────────────────────────────────────────────────────────────────────────
// HTTP error → ApiException bridge (used by ALL repositories)
// ────────────────────────────────────────────────────────────────────────────

/**
 * Convert a Retrofit [retrofit2.HttpException] into a user-facing [ApiException]
 * by extracting the structured error message from the response body.
 *
 * The backend returns errors in this shape for all non-2xx responses:
 *   `{ "ok": false, "error": { "message": "...", "code": "...", "detail": "..." } }`
 *
 * When the body parses cleanly, the user sees the server's message verbatim
 * (e.g. "Invalid email or password", "This username is already taken.",
 * "Post not found.", "Article not found.").
 *
 * When the body is not JSON (e.g. a Netlify 404 "Not Found" page — the
 * classic symptom of a wrong Base URL), the function falls back to a
 * human-readable hint based on the HTTP code.
 *
 * Special cases:
 *   - HTTP 404: if the body is structured JSON, the server's message is
 *     shown verbatim (e.g. "Post not found." when the user clicks on a
 *     deleted post). Only when the body is NOT JSON do we fall back to the
 *     "the server URL may have changed" hint — this happens when the Base
 *     URL itself is wrong (Netlify returns a plain-text "Not Found" page).
 *   - HTTP 403: usually a CSRF check failure (the Origin header doesn't
 *     match the deployment URL). The hint points to the Origin config +
 *     includes the actual URL the request was sent with.
 *   - HTTP 429: rate-limited. The hint tells the user to wait.
 *   - HTTP 5xx: server-side error. The hint says to try again later.
 */
fun retrofit2.HttpException.toApiException(): ApiException {
    val code = this.code()
    // The actual URL the request was sent to — exposed by OkHttp via the
    // raw response. This is the single most useful piece of diagnostic
    // info when the URL is wrong: the user sees "I sent the request to
    // <X> and got HTTP 404" — which makes the fix obvious.
    val requestUrl = try {
        this.response()?.raw()?.request?.url?.toString() ?: "(unknown URL)"
    } catch (_: Exception) {
        "(unknown URL)"
    }
    // Try to parse the structured error body. The backend ALWAYS returns
    // structured JSON for application-level errors (Post not found, etc.).
    val rawBody = try {
        this.response()?.errorBody()?.string()
    } catch (_: Exception) {
        null
    }
    val serverMessage = rawBody?.let { parseErrorMessage(it) }
    val message = serverMessage ?: when (code) {
        404 -> "The server could not be reached at the configured URL.\n" +
            "Request URL: $requestUrl\n" +
            "If you are the developer, check API_BASE_URL in app/build.gradle.kts — " +
            "the deployment URL may have changed. The current production URL is " +
            "https://sentrychat.netlify.app."
        403 -> "Request blocked by the server's security policy (CSRF check).\n" +
            "Request URL: $requestUrl\n" +
            "If you are the developer, check that API_ORIGIN in app/build.gradle.kts " +
            "matches the deployment URL exactly (the backend's CSRF check compares them)."
        429 -> "Too many requests. Please wait a moment and try again."
        in 500..599 -> "The server had an error (HTTP $code). Please try again later."
        else -> "Request failed (HTTP $code).\nURL: $requestUrl"
    }
    return ApiException(message, code.toString())
}

/**
 * Parse the structured `{ "ok": false, "error": { "message": "..." } }` body
 * and return the inner message. Returns null if the body is not valid JSON
 * or doesn't match the expected shape (e.g. a plain-text Netlify 404 page).
 */
fun parseErrorMessage(rawBody: String): String? {
    return try {
        val json = org.json.JSONObject(rawBody)
        // The backend always wraps errors under `error.message`.
        val errorObj = json.optJSONObject("error") ?: return null
        errorObj.optString("message").takeIf { it.isNotBlank() }
    } catch (_: Exception) {
        null
    }
}

/**
 * Wraps a Retrofit + kotlinx-serialization API call with structured error
 * extraction. Used by every non-auth repository (Profile, Articles, Posts,
 * Feed, Notifications, Search) so that HTTP 4xx/5xx responses surface the
 * backend's structured error message verbatim instead of the generic
 * "HTTP 404 ..." string that Retrofit's [retrofit2.HttpException] carries
 * by default.
 *
 * BEHAVIOR:
 *  - HTTP 2xx + `{ok:true, data:{...}}` → returns the unwrapped `data` payload.
 *  - HTTP 2xx + `{ok:false, error:{message:"..."}}` → throws [ApiException]
 *    with the server's message (rare; the backend usually uses 4xx/5xx
 *    for errors).
 *  - HTTP 4xx/5xx + structured JSON body → throws [ApiException] with the
 *    server's `error.message` verbatim (e.g. "Post not found.").
 *  - HTTP 4xx/5xx + non-JSON body (Netlify "site not found" page) → throws
 *    [ApiException] with a hint based on the HTTP code (see [toApiException]).
 *  - Network failure (no DNS, no route, SSL handshake) → throws
 *    [java.io.IOException] with a friendly "Could not connect…" message.
 *
 * USAGE:
 *   suspend fun getArticle(id: String): ArticleDetailDto =
 *       safeApiCall { api.getArticle(id) }.article
 *
 * The `block` is the suspend lambda that returns the raw `ApiResponse<T>`.
 * The function awaits it, extracts the data, and applies the error handling.
 */
suspend fun <T> safeApiCall(block: suspend () -> ApiResponse<T>): T {
    val response = try {
        block()
    } catch (e: retrofit2.HttpException) {
        throw e.toApiException()
    } catch (e: java.io.IOException) {
        throw java.io.IOException(
            "Could not connect to the server. Check your internet connection and try again.",
            e,
        )
    }
    return response.dataOrThrow()
}
