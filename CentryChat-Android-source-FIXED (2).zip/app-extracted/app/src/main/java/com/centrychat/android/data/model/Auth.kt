package com.centrychat.android.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Authentication request/response DTOs.
 *
 * These mirror the request body shapes accepted by the corresponding backend
 * routes (src/app/api/v1/auth routes). Field names use camelCase so they match
 * the JSON consumed by the web client — the backend's `parseJsonBody` already
 * lowercases emails, so the Android client doesn't have to.
 */

@Serializable
data class LoginRequest(
    val email: String,
    val password: String,
)

@Serializable
data class RegisterRequest(
    val fullName: String,
    val email: String,
    val username: String,
    val password: String,
    val confirmPassword: String,
    val gender: String,
    val dateOfBirth: String? = null,
    val countryCode: String,
)

@Serializable
data class ForgotPasswordRequest(
    val email: String,
)

@Serializable
data class ResetPasswordRequest(
    val token: String,
    val password: String,
    val confirmPassword: String,
)

/**
 * The response body for `/api/v1/auth/login` and `/api/v1/auth/register`.
 *
 * `sessionId` is informational — the actual session is carried by the cookie
 * that the backend sets via the Set-Cookie header. The cookie is captured
 * automatically by OkHttp's [PersistentCookieJar].
 *
 * `user` IS NULLABLE on purpose — the backend's register route has an
 * anti-enumeration branch: when an existing email is submitted, it returns
 * `{"ok":true,"data":{"registered":true,"verificationRequired":true}}`
 * WITHOUT a `user` object + WITHOUT a `sessionId` (so an attacker can't tell
 * whether the account was just created or already existed). The Android
 * client must handle this case gracefully — see [AuthRepository.register].
 */
@Serializable
data class LoginResponse(
    val sessionId: String? = null,
    val user: UserDto? = null,
    val requiresVerification: Boolean = false,
    val registered: Boolean = false,
)

/**
 * Response body for `/api/v1/auth/me`.
 *
 * `user` is nullable: when there is no session cookie (or the session has
 * expired), the backend returns `{"ok":true,"data":{"user":null}}` — the
 * `ok` flag is still `true` (the request itself was successful) but the
 * payload is a null user. The caller treats `user == null` as "not logged in".
 */
@Serializable
data class AuthMeResponse(
    val user: UserDto? = null,
)

/**
 * Generic `{ message: "..." }` response — used by logout, forgot-password,
 * reset-password, and any endpoint that just returns a status string.
 */
@Serializable
data class GenericMessageResponse(
    val sent: Boolean? = null,
    val reset: Boolean? = null,
    val message: String? = null,
)
