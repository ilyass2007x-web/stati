package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.AdminAuditListResponse
import com.centrychat.android.data.model.AdminContentListResponse
import com.centrychat.android.data.model.AdminDashboardResponse
import com.centrychat.android.data.model.AdminFeaturesResponse
import com.centrychat.android.data.model.AdminMyPermissionsResponse
import com.centrychat.android.data.model.AdminSecurityResponse
import com.centrychat.android.data.model.AdminSettingsResponse
import com.centrychat.android.data.model.AdminSystemResponse
import com.centrychat.android.data.model.AdminUserDetailResponse
import com.centrychat.android.data.model.AdminUsersListResponse
import com.centrychat.android.data.model.AdMobAppUpdateBody
import com.centrychat.android.data.model.AdMobAppUpdateResponse
import com.centrychat.android.data.model.AdMobAppsResponse
import com.centrychat.android.data.model.AdMobSettingsResponse
import com.centrychat.android.data.model.AdMobSettingsUpdateBody
import com.centrychat.android.data.model.AdUnitCreateBody
import com.centrychat.android.data.model.AdUnitResponse
import com.centrychat.android.data.model.AdUnitUpdateBody
import com.centrychat.android.data.model.AdUnitsListResponse
import com.centrychat.android.data.model.safeApiCall

/**
 * Admin repository — wraps all `/api/v1/admin/[section]` endpoints.
 *
 * ROLE GATING (UI side):
 *  - The Android client gates admin UI on `Roles.canAccessAdmin(user)`.
 *    Non-admins never see the Admin entry in the bottom nav or settings.
 *  - Even if a non-admin somehow constructs an admin HTTP request (e.g.
 *    via adb), the backend enforces `requireAdmin()` + `requirePermission()`
 *    server-side → HTTP 403 + `{"ok":false,"error":{"message":"Forbidden"}}`.
 *  - The Android client's `safeApiCall` extracts that 403 message and
 *    surfaces it to the user — no escalation, no bypass.
 *
 * PERMISSION KEYS:
 *  - Each admin method here corresponds to a permission key in
 *    [com.centrychat.android.core.security.Permissions] (e.g. `adminGetUsers`
 *    needs `USERS_VIEW`).
 *  - The Android client does NOT enforce these locally — the backend does.
 *    The local permission catalog is only used to decide which admin
 *    sections to show in the UI (see `AdminDashboardScreen`).
 */
class AdminRepository(
    private val api: CentryChatApi,
) {
    private val origin: String = BuildConfig.API_ORIGIN

    /** Admin dashboard overview — `GET /api/v1/admin/dashboard`. */
    suspend fun getDashboard(): AdminDashboardResponse =
        safeApiCall { api.adminGetDashboard() }

    /** List users with optional search + cursor pagination. */
    suspend fun getUsers(
        cursor: String? = null,
        limit: Int = 50,
        search: String? = null,
    ): AdminUsersListResponse =
        safeApiCall { api.adminGetUsers(limit = limit, cursor = cursor, search = search) }

    /** Single user detail (includes moderation history + permissions). */
    suspend fun getUser(id: String): AdminUserDetailResponse =
        safeApiCall { api.adminGetUser(id) }

    /** Perform an admin action on a user (SUSPEND / UNSUSPEND / BAN / VERIFY / etc.). */
    suspend fun userAction(
        id: String,
        action: String,
        reason: String? = null,
        newRole: String? = null,
    ): Boolean {
        val body = buildMap<String, String?> {
            put("action", action)
            reason?.let { put("reason", it) }
            newRole?.let { put("role", it) }
        }
        safeApiCall { api.adminUserAction(id = id, body = body, origin = origin) }
        return true
    }

    /** Verify a user's email (blue badge). */
    suspend fun verifyUser(id: String): Boolean {
        safeApiCall { api.adminVerifyUser(id = id, origin = origin) }
        return true
    }

    /** List all content (posts + articles) with optional type filter. */
    suspend fun getContent(
        cursor: String? = null,
        limit: Int = 50,
        type: String? = null,
    ): AdminContentListResponse =
        safeApiCall { api.adminGetContent(limit = limit, cursor = cursor, type = type) }

    /** Perform an admin action on a content item (FEATURE / UNFEATURE / DELETE / etc.). */
    suspend fun contentAction(id: String, action: String, reason: String? = null): Boolean {
        val body = buildMap<String, String?> {
            put("action", action)
            reason?.let { put("reason", it) }
        }
        safeApiCall { api.adminContentAction(id = id, body = body, origin = origin) }
        return true
    }

    /** List platform settings (raw key/value table). */
    suspend fun getSettings(): AdminSettingsResponse =
        safeApiCall { api.adminGetSettings() }

    /** List feature flags (messaging / search / video_chat / etc.). */
    suspend fun getFeatures(): AdminFeaturesResponse =
        safeApiCall { api.adminGetFeatures() }

    /** Paginated audit log. */
    suspend fun getAudit(
        cursor: String? = null,
        limit: Int = 50,
    ): AdminAuditListResponse =
        safeApiCall { api.adminGetAudit(limit = limit, cursor = cursor) }

    /** System info (Node version, uptime, memory, providers). */
    suspend fun getSystem(): AdminSystemResponse =
        safeApiCall { api.adminGetSystem() }

    /** Security info (security headers, rate limits, audit summary). */
    suspend fun getSecurity(): AdminSecurityResponse =
        safeApiCall { api.adminGetSecurity() }

    /** The current admin's role + permissions + isSuperAdmin flag.
     *  Used to decide which admin sections to show in the UI. */
    suspend fun getMyPermissions(): AdminMyPermissionsResponse =
        safeApiCall { api.adminGetMyPermissions() }

    /** Broadcast a notification to all / active users. */
    suspend fun broadcastNotification(
        title: String,
        message: String,
        audience: String = "all",
    ): Boolean {
        val body = mapOf<String, String?>(
            "title" to title,
            "message" to message,
            "audience" to audience,
        )
        safeApiCall { api.adminBroadcastNotification(body = body, origin = origin) }
        return true
    }

    // ── Publishing & Ad Units (replaces web "AdMob" section) ──────────
    // These wrap `/api/v1/admin/admob/*` endpoints. The backend source of
    // truth is shared with the web — no Android-only ad system. Edits from
    // Android appear in the web admin instantly.

    /** List all ad units with optional filters. Server enforces ADS_VIEW. */
    suspend fun getAdUnits(
        platform: String? = null,
        search: String? = null,
        status: String? = null,
        placement: String? = null,
        format: String? = null,
    ): AdUnitsListResponse =
        safeApiCall {
            api.adminGetAdUnits(
                platform = platform,
                search = search,
                status = status,
                placement = placement,
                format = format,
            )
        }

    /** Create a new ad unit. Server enforces ADS_MANAGE. */
    suspend fun createAdUnit(body: AdUnitCreateBody): AdUnitResponse =
        safeApiCall { api.adminCreateAdUnit(body = body, origin = origin) }

    /** Update an ad unit (partial). Server enforces ADS_MANAGE. */
    suspend fun updateAdUnit(id: String, body: AdUnitUpdateBody): AdUnitResponse =
        safeApiCall { api.adminUpdateAdUnit(id = id, body = body, origin = origin) }

    /** Delete an ad unit. Server enforces ADS_MANAGE. */
    suspend fun deleteAdUnit(id: String): Boolean {
        safeApiCall { api.adminDeleteAdUnit(id = id, origin = origin) }
        return true
    }

    /** Quick-toggle the `active` flag on an ad unit. Server enforces ADS_MANAGE. */
    suspend fun toggleAdUnitActive(id: String, active: Boolean): AdUnitResponse =
        safeApiCall {
            api.adminUpdateAdUnit(
                id = id,
                body = AdUnitUpdateBody(active = active),
                origin = origin,
            )
        }

    /** List AdMob apps (Android + iOS rows). Server enforces ADS_VIEW. */
    suspend fun getAdMobApps(): AdMobAppsResponse =
        safeApiCall { api.adminGetAdMobApps() }

    /** Update one AdMob app (identified by `platform` in the body). */
    suspend fun updateAdMobApp(body: AdMobAppUpdateBody): AdMobAppUpdateResponse =
        safeApiCall { api.adminUpdateAdMobApp(body = body, origin = origin) }

    /** Read global AdMob settings (enabled, environment, min versions, config version). */
    suspend fun getAdMobSettings(): AdMobSettingsResponse =
        safeApiCall { api.adminGetAdMobSettings() }

    /** Update global AdMob settings. */
    suspend fun updateAdMobSettings(body: AdMobSettingsUpdateBody): AdMobSettingsResponse =
        safeApiCall { api.adminUpdateAdMobSettings(body = body, origin = origin) }
}
