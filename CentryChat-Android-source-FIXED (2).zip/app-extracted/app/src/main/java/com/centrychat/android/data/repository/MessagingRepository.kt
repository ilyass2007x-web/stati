package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.ConversationDto
import com.centrychat.android.data.model.MessageDto
import com.centrychat.android.data.model.MessageEnvelope
import com.centrychat.android.data.model.safeApiCall

/**
 * Messaging repository — wraps `/api/v1/conversations` and
 * `/api/v1/conversations/{id}/messages` endpoints.
 *
 * The backend requires `requireVerifiedUser()` on every messaging route
 * — unverified users get HTTP 403. The `messaging` FeatureFlag must also
 * be enabled (admin-controlled) — if disabled, the backend returns
 * `{ conversations: [] }` for list and `400 "Messaging is currently
 * disabled"` for create.
 *
 * REAL-TIME: the web uses socket.io for live typing + message arrival.
 * The Android app uses a polling fallback every 15s (same as the web's
 * MainNav unread-count badge fallback). Real-time socket.io integration
 * (using `io.socket:socket.io-client` Java library) is tracked as a
 * follow-up — the cookie-authenticated handshake is already supported
 * by the backend's realtime mini-service on port 3003.
 */
class MessagingRepository(
    private val api: CentryChatApi,
) {
    private val origin: String = BuildConfig.API_ORIGIN

    /** List the current user's conversations (most recent first). */
    suspend fun getConversations(): List<ConversationDto> =
        safeApiCall { api.getConversations() }.conversations

    /** Get or create a 1:1 direct conversation with the target user.
     *  The backend's `getOrCreateDirectConversation` is idempotent —
     *  calling with the same userId always returns the same conversation. */
    suspend fun getOrCreateDirect(userId: String): ConversationDto {
        val body = mapOf<String, String?>("userId" to userId)
        val response = safeApiCall { api.createConversation(body = body, origin = origin) }
        // The backend wraps the conversation under `data.conversation`.
        return response.conversation ?: throw java.io.IOException(
            "Conversation was not returned by the backend."
        )
    }

    /** Fetch a single conversation by ID (includes the participant list). */
    suspend fun getConversation(id: String): ConversationDto =
        safeApiCall { api.getConversation(id) }

    /** Fetch paginated messages for a conversation (most recent first). */
    suspend fun getMessages(
        conversationId: String,
        beforeId: String? = null,
        limit: Int = 50,
    ): List<MessageDto> =
        safeApiCall { api.getMessages(id = conversationId, limit = limit, beforeId = beforeId) }.messages

    /** Send a text message to a conversation. Returns the newly created message.
     *
     *  The backend wraps the new message under `data.message` (NOT directly
     *  under `data`), so the API interface returns [MessageEnvelope] and we
     *  extract `.message` here. Without this unwrap the previous code crashed
     *  with `SerializationException: Field 'id' is required for type
     *  MessageDto, but it was missing at path: S.data`. */
    suspend fun sendMessage(conversationId: String, content: String): MessageDto {
        val body = mapOf<String, String?>("content" to content)
        val envelope: MessageEnvelope = safeApiCall {
            api.sendMessage(id = conversationId, body = body, origin = origin)
        }
        return envelope.message
    }

    /** Mark all messages in a conversation as read. */
    suspend fun markRead(conversationId: String): Boolean {
        safeApiCall { api.markConversationRead(id = conversationId, origin = origin) }
        return true
    }

    /** Edit a message (sender only). Backend soft-edits + sets isEdited=true. */
    suspend fun editMessage(messageId: String, newContent: String): Boolean {
        val body = mapOf<String, String?>("content" to newContent)
        safeApiCall { api.editMessage(id = messageId, body = body, origin = origin) }
        return true
    }

    /** Soft-delete a message (sender only). Sets isDeleted=true. */
    suspend fun deleteMessage(messageId: String): Boolean {
        safeApiCall { api.deleteMessage(id = messageId, origin = origin) }
        return true
    }
}
