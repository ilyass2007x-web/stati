package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.PlaylistDto
import com.centrychat.android.data.model.PlaylistItemsResponse
import com.centrychat.android.data.model.PlaylistsListResponse
import com.centrychat.android.data.model.safeApiCall

/**
 * Playlists repository — wraps `/api/v1/playlists/[endpoint]`.
 *
 * Ordered collections of ARTICLES ONLY (independent from Collections).
 * Limits: 100 playlists/user, 200 items/playlist (admin-configurable).
 * Public playlists get SSR + JSON-LD ItemList on the web.
 */
class PlaylistsRepository(
    private val api: CentryChatApi,
) {
    private val origin: String = BuildConfig.API_ORIGIN

    /** List the current user's playlists. */
    suspend fun getPlaylists(limit: Int = 50): PlaylistsListResponse =
        safeApiCall { api.getPlaylists(limit = limit) }

    /** List a specific user's playlists (public-only for non-owners).
     *
     *  Used by the Profile screen's Playlists tab. The global
     *  `/api/v1/playlists` returns ONLY the CURRENT user's playlists —
     *  using it on someone else's profile returned an empty list. This
     *  method calls `/api/v1/users/{username}/playlists`, which is
     *  public-friendly (returns public playlists for non-owners, all
     *  playlists for the owner, all for admins).
     *
     *  The backend's response includes extra `total` / `page` / `limit`
     *  fields that we don't need — `ignoreUnknownKeys = true` in the Json
     *  config silently drops them. We only consume `playlists`. */
    suspend fun getUserPlaylists(username: String, limit: Int = 100): PlaylistsListResponse =
        safeApiCall { api.getUserPlaylists(username = username, limit = limit) }

    /** Create a new playlist. */
    suspend fun createPlaylist(
        name: String,
        description: String? = null,
        visibility: String = "PRIVATE",
    ): PlaylistDto {
        val body = mapOf<String, String?>(
            "name" to name,
            "description" to description,
            "visibility" to visibility,
        )
        return safeApiCall { api.createPlaylist(body = body, origin = origin) }
    }

    /** Fetch a single playlist by ID.
     *
     *  The backend wraps the playlist under `data.playlist` (NOT
     *  directly under `data`), so the API interface returns
     *  [PlaylistDetailResponse] and we extract `.playlist` here.
     *  Without this unwrap, kotlinx-serialization crashed with
     *  `Fields [id, name, slug] are required for PlaylistDto at
     *  path: S.data` because `data` actually contains a `playlist`
     *  field, not the playlist's fields directly.
     *
     *  Throws [java.io.IOException] when the backend returns
     *  `playlist: null` (shouldn't happen on success, but is the
     *  defensive behavior the calling ViewModel expects when something
     *  goes wrong). */
    suspend fun getPlaylist(id: String): PlaylistDto {
        val envelope = safeApiCall { api.getPlaylist(id) }
        return envelope.playlist ?: throw java.io.IOException("Playlist was not returned by the backend.")
    }

    /** Delete a playlist. */
    suspend fun deletePlaylist(id: String): Boolean {
        safeApiCall { api.deletePlaylist(id = id, origin = origin) }
        return true
    }

    /** Fetch items (articles) in a playlist. */
    suspend fun getItems(id: String, limit: Int = 50): PlaylistItemsResponse =
        safeApiCall { api.getPlaylistItems(id = id, limit = limit) }

    /** Add an article to a playlist. */
    suspend fun addArticle(playlistId: String, articleId: String): Boolean {
        val body = mapOf<String, String?>("articleId" to articleId)
        safeApiCall { api.addPlaylistItem(id = playlistId, body = body, origin = origin) }
        return true
    }

    /** Remove an article from a playlist. */
    suspend fun removeArticle(playlistId: String, itemId: String): Boolean {
        safeApiCall { api.removePlaylistItem(id = playlistId, itemId = itemId, origin = origin) }
        return true
    }
}
