package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.ProfileResponse
import com.centrychat.android.data.model.UserProfileSummary
import com.centrychat.android.data.model.UsersListResponse
import com.centrychat.android.data.model.safeApiCall

/**
 * Profile repository.
 *
 * Wraps:
 *  - The current user's profile (`/api/v1/profile` GET + PATCH)
 *  - Public profiles by username (`/api/v1/users/{username}/profile`)
 *  - Follow / unfollow (`/api/v1/users/{username}/follow`)
 *  - Followers + following lists
 *
 * ERROR HANDLING: every API call goes through [safeApiCall] which extracts
 * the structured `error.message` from non-2xx responses (e.g. "User not
 * found." on a 404, "You cannot follow yourself." on a 400). Without this,
 * the ViewModel would display a generic "HTTP 404 ..." string from
 * Retrofit's default HttpException message.
 */
class ProfileRepository(
    private val api: CentryChatApi,
) {
    private val origin: String = BuildConfig.API_ORIGIN

    /** Fetch the current user's full profile (includes private fields). */
    suspend fun getMyProfile(): ProfileResponse {
        return safeApiCall { api.getMyProfile() }
    }

    /** Update the current user's profile. Pass only the fields to change. */
    suspend fun updateMyProfile(changes: Map<String, Any?>): ProfileResponse {
        return safeApiCall { api.updateMyProfile(body = changes, origin = origin) }
    }

    /** Fetch a public profile by username.
     *
     *  The backend wraps the profile under `data.profile` (NOT directly
     *  under `data`), so the API interface returns [UserProfileResponse]
     *  and we extract `.profile` here. See [UserProfileResponse] for the
     *  rationale. */
    suspend fun getPublicProfile(username: String): UserProfileSummary {
        return safeApiCall { api.getUserProfile(username = username) }.profile
    }

    /** Follow a user. */
    suspend fun follow(username: String): Boolean {
        safeApiCall { api.followUser(username = username, origin = origin) }
        return true
    }

    /** Unfollow a user. */
    suspend fun unfollow(username: String): Boolean {
        safeApiCall { api.unfollowUser(username = username, origin = origin) }
        return true
    }

    /** Fetch a user's followers (paginated). */
    suspend fun getFollowers(
        username: String,
        cursor: String? = null,
        limit: Int = 20,
    ): UsersListResponse {
        return safeApiCall {
            api.getFollowers(
                username = username,
                limit = limit,
                cursor = cursor,
            )
        }
    }

    /** Fetch the users a user is following (paginated). */
    suspend fun getFollowing(
        username: String,
        cursor: String? = null,
        limit: Int = 20,
    ): UsersListResponse {
        return safeApiCall {
            api.getFollowing(
                username = username,
                limit = limit,
                cursor = cursor,
            )
        }
    }

    /** Fetch a list of suggested users (for the "Who to follow" widget). */
    suspend fun getSuggestedUsers(): List<UserProfileSummary> {
        return safeApiCall { api.getSuggestedUsers() }.users
    }
}
