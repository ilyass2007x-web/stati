package com.centrychat.android.data.repository

import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.SearchAllResponse
import com.centrychat.android.data.model.UserProfileSummary
import com.centrychat.android.data.model.safeApiCall

/**
 * Search repository.
 *
 * Wraps the `/api/v1/search/all` endpoint (combined search across users,
 * posts, and articles). The backend uses PostgreSQL trigram indexes for
 * fuzzy matching — the client just sends the raw query string.
 *
 * ERROR HANDLING: every API call goes through [safeApiCall] which extracts
 * the structured `error.message` from non-2xx responses. Without this,
 * the ViewModel would display a generic "HTTP ..." string from Retrofit's
 * default HttpException message.
 */
class SearchRepository(
    private val api: CentryChatApi,
) {
    /** Search users, posts, and articles in one request. */
    suspend fun searchAll(query: String, limit: Int = 20): SearchAllResponse {
        return safeApiCall { api.searchAll(query = query.trim(), limit = limit) }
    }

    /** Search users only (used for the @-mention autocomplete + the
     *  followers/following lists' search bar). */
    suspend fun searchUsers(query: String): List<UserProfileSummary> {
        return safeApiCall { api.searchUsers(query = query.trim()) }.users
    }
}
