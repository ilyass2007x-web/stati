package com.centrychat.android.feature.admin

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.centrychat.android.R
import com.centrychat.android.core.security.Permissions
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.AdminContentStats
import com.centrychat.android.data.model.AdminDashboardResponse
import com.centrychat.android.data.model.AdminModerationStats
import com.centrychat.android.data.model.AdminSessionsStats
import com.centrychat.android.data.model.AdminUsersStats
import com.centrychat.android.rememberAdminViewModel

/**
 * Admin Dashboard screen.
 *
 * Shows an overview of platform stats (users / content / moderation /
 * sessions) + a list of admin sections (Users, Content, Settings, Audit,
 * System, Security, Broadcast).
 *
 * ROLE GATING (UI side):
 *  - The screen itself is only reachable when the bottom-nav "Admin" item
 *    is visible — which only happens for ADMIN/SUPER_ADMIN (see
 *    [com.centrychat.android.navigation.BottomNavDestination.ADMIN] +
 *    `adminOnly` flag).
 *  - The dashboard data is fetched via `/api/v1/admin/dashboard` which
 *    requires `requireAdmin()` server-side → HTTP 403 for non-admins.
 *  - If a non-admin somehow reaches this screen (e.g. deep-link), the
 *    backend's 403 response is caught + the UI shows an "access denied"
 *    message instead of the dashboard.
 *
 * PERMISSION GATING (UI side):
 *  - Each admin section is only shown if the current admin has the
 *    corresponding `*_VIEW` permission. SUPER_ADMIN sees everything.
 *  - Tapping a section navigates to that section's screen, which itself
 *    fetches the corresponding admin endpoint → another 403 if the
 *    permission is missing.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    onSectionClick: (section: String) -> Unit,
    onBack: () -> Unit,
) {
    val viewModel = rememberAdminViewModel()
    val permsState by viewModel.permissionsState.collectAsStateWithLifecycle()
    val dashboardState by viewModel.dashboardState.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) { viewModel.load() }

    Scaffold(
        topBar = {
            androidx.compose.material3.TopAppBar(
                title = { Text(stringResource(R.string.admin_dashboard_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState()),
        ) {
            when (val s = permsState) {
                is UiState.Loading -> Row(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    horizontalArrangement = Arrangement.Center,
                ) { CircularProgressIndicator() }
                is UiState.Error -> Column(Modifier.padding(24.dp)) {
                    Text(
                        stringResource(R.string.admin_forbidden),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.error,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(s.message, style = MaterialTheme.typography.bodySmall)
                }
                is UiState.Success -> {
                    val perms = s.data
                    Column(Modifier.padding(16.dp)) {
                        // ── Role + permission summary ─────────────────────
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                            ),
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text(
                                    "Signed in as ${perms.role}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                )
                                if (perms.isSuperAdmin) {
                                    Text(
                                        "Super admin — all permissions granted.",
                                        style = MaterialTheme.typography.bodySmall,
                                    )
                                } else {
                                    Text(
                                        "${perms.permissions.size} permission(s) granted.",
                                        style = MaterialTheme.typography.bodySmall,
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.height(16.dp))

                        // ── Dashboard overview stats ─────────────────────
                        when (val d = dashboardState) {
                            is UiState.Loading -> Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                            ) { CircularProgressIndicator() }
                            is UiState.Error -> Text(
                                d.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.error,
                            )
                            is UiState.Success -> DashboardStatsCard(d.data)
                            is UiState.Empty -> {}
                        }

                        Spacer(Modifier.height(16.dp))

                        // ── Admin sections (permission-gated) ───────────
                        Text(
                            "Sections",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(vertical = 8.dp),
                        )
                        AdminSectionList(
                            perms = perms.permissions.toSet(),
                            isSuperAdmin = perms.isSuperAdmin,
                            onSectionClick = onSectionClick,
                        )
                    }
                }
                is UiState.Empty -> {}
            }
        }
    }
}

@Composable
private fun DashboardStatsCard(d: AdminDashboardResponse) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("Platform stats", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            d.users?.let { StatsRow("Total users", it.total.toString()) }
            d.users?.let { StatsRow("Active", it.active.toString()) }
            d.users?.let { StatsRow("Suspended", it.suspended.toString()) }
            d.users?.let { StatsRow("Banned", it.banned.toString()) }
            d.users?.let { StatsRow("Pending verification", it.pendingVerification.toString()) }
            d.users?.let { StatsRow("New today", it.newToday.toString()) }
            d.content?.let {
                Spacer(Modifier.height(8.dp))
                StatsRow("Posts", it.posts.toString())
                StatsRow("Articles", it.articles.toString())
                StatsRow("Pending review", it.pending.toString())
                StatsRow("Flagged", it.flagged.toString())
            }
            d.moderation?.let {
                Spacer(Modifier.height(8.dp))
                StatsRow("Moderation queue", it.pending.toString())
                StatsRow("Reviewed", it.reviewed.toString())
                StatsRow("Blocked", it.blocked.toString())
            }
            d.sessions?.let {
                Spacer(Modifier.height(8.dp))
                StatsRow("Active sessions", it.active.toString())
                StatsRow("Last 24h", it.last24h.toString())
            }
        }
    }
}

@Composable
private fun StatsRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun AdminSectionList(
    perms: Set<String>,
    isSuperAdmin: Boolean,
    onSectionClick: (String) -> Unit,
) {
    val allSections = listOf(
        AdminSection("users", R.string.admin_section_users, Icons.Filled.Group, Permissions.USERS_VIEW),
        AdminSection("content", R.string.admin_section_content, Icons.Filled.ListAlt, Permissions.CONTENT_VIEW),
        AdminSection("settings", R.string.admin_section_settings, Icons.Filled.Settings, Permissions.SETTINGS_VIEW),
        AdminSection("features", R.string.admin_section_features, Icons.Filled.Tune, Permissions.FEATURES_VIEW),
        AdminSection("audit", R.string.admin_section_audit, Icons.Filled.BugReport, Permissions.AUDIT_VIEW),
        AdminSection("system", R.string.admin_section_system, Icons.Filled.Dashboard, Permissions.SYSTEM_VIEW),
        AdminSection("security", R.string.admin_section_security, Icons.Filled.Lock, Permissions.SECURITY_VIEW),
        AdminSection("broadcast", R.string.admin_section_broadcast, Icons.Filled.Campaign, Permissions.NOTIFICATIONS_MANAGE),
        // Publishing & Ad Units — replaces the web's standalone "AdMob" section.
        // Gated by ADS_VIEW. The same backend `/api/v1/admin/admob/` routes serve
        // both the web admin and this Android section — edits sync both ways.
        AdminSection("adunits", R.string.admin_section_adunits, Icons.Filled.Tune, Permissions.ADS_VIEW),
    )
    val visibleSections = allSections.filter {
        isSuperAdmin || Permissions.hasPermission(perms, it.permission)
    }
    Column {
        visibleSections.forEach { section ->
            AdminSectionRow(section, onClick = { onSectionClick(section.route) })
        }
    }
}

private data class AdminSection(
    val route: String,
    val labelRes: Int,
    val icon: ImageVector,
    val permission: String,
)

@Composable
private fun AdminSectionRow(section: AdminSection, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = section.icon,
                contentDescription = null,
                modifier = Modifier.size(24.dp),
                tint = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.size(16.dp))
            Text(
                stringResource(section.labelRes),
                style = MaterialTheme.typography.bodyLarge,
            )
        }
    }
}
