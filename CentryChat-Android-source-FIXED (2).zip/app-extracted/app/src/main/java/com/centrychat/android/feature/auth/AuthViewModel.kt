package com.centrychat.android.feature.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.TextUtils
import com.centrychat.android.data.repository.AuthRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * The authentication flow state.
 *
 * Tracks:
 *  - The current form values (email, password, etc.)
 *  - Whether a network request is in-flight
 *  - The latest error message (or null)
 *  - The "success" event (one-shot — observed by the UI to navigate forward)
 */
data class AuthUiState(
    val email: String = "",
    val password: String = "",
    val confirmPassword: String = "",
    val fullName: String = "",
    val username: String = "",
    val gender: String = "",
    val countryCode: String = "",
    val dateOfBirth: String = "",
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val successEvent: Boolean = false,
)

class AuthViewModel(
    private val appContainer: AppContainer,
) : ViewModel() {

    private val repo: AuthRepository = appContainer.authRepository

    private val _loginState = MutableStateFlow(AuthUiState())
    val loginState: StateFlow<AuthUiState> = _loginState.asStateFlow()

    private val _registerState = MutableStateFlow(AuthUiState())
    val registerState: StateFlow<AuthUiState> = _registerState.asStateFlow()

    private val _forgotState = MutableStateFlow(AuthUiState())
    val forgotState: StateFlow<AuthUiState> = _forgotState.asStateFlow()

    private val _resetState = MutableStateFlow(AuthUiState())
    val resetState: StateFlow<AuthUiState> = _resetState.asStateFlow()

    // ── Login ──────────────────────────────────────────────────────────

    fun onLoginEmailChange(value: String) {
        _loginState.update { it.copy(email = value, errorMessage = null) }
    }

    fun onLoginPasswordChange(value: String) {
        _loginState.update { it.copy(password = value, errorMessage = null) }
    }

    fun login() {
        val state = _loginState.value
        if (state.isLoading) return
        if (!TextUtils.isValidEmail(state.email)) {
            _loginState.update { it.copy(errorMessage = "Please enter a valid email address.") }
            return
        }
        if (state.password.isBlank()) {
            _loginState.update { it.copy(errorMessage = "Please enter your password.") }
            return
        }
        _loginState.update { it.copy(isLoading = true, errorMessage = null) }
        viewModelScope.launch {
            try {
                repo.login(state.email, state.password)
                _loginState.update { it.copy(isLoading = false, successEvent = true) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _loginState.update {
                    it.copy(isLoading = false, errorMessage = e.message ?: "Login failed.")
                }
            }
        }
    }

    fun consumeLoginSuccess() {
        _loginState.update { it.copy(successEvent = false) }
    }

    // ── Register ───────────────────────────────────────────────────────

    fun onRegisterFieldChange(
        email: String? = null,
        password: String? = null,
        confirmPassword: String? = null,
        fullName: String? = null,
        username: String? = null,
        gender: String? = null,
        countryCode: String? = null,
        dateOfBirth: String? = null,
    ) {
        _registerState.update { current ->
            current.copy(
                email = email ?: current.email,
                password = password ?: current.password,
                confirmPassword = confirmPassword ?: current.confirmPassword,
                fullName = fullName ?: current.fullName,
                username = username ?: current.username,
                gender = gender ?: current.gender,
                countryCode = countryCode ?: current.countryCode,
                dateOfBirth = dateOfBirth ?: current.dateOfBirth,
                errorMessage = null,
            )
        }
    }

    fun register() {
        val state = _registerState.value
        if (state.isLoading) return
        if (state.fullName.isBlank()) {
            _registerState.update { it.copy(errorMessage = "Please enter your full name.") }
            return
        }
        if (!TextUtils.isValidEmail(state.email)) {
            _registerState.update { it.copy(errorMessage = "Please enter a valid email address.") }
            return
        }
        if (!TextUtils.isValidUsername(state.username)) {
            _registerState.update { it.copy(errorMessage = "Username must be 3-30 letters, numbers, or underscores.") }
            return
        }
        if (state.password.length < 8) {
            _registerState.update { it.copy(errorMessage = "Password must be at least 8 characters.") }
            return
        }
        if (state.password != state.confirmPassword) {
            _registerState.update { it.copy(errorMessage = "Passwords do not match.") }
            return
        }
        if (state.gender.isBlank()) {
            _registerState.update { it.copy(errorMessage = "Please select your gender.") }
            return
        }
        if (state.countryCode.isBlank()) {
            _registerState.update { it.copy(errorMessage = "Please select your country.") }
            return
        }
        _registerState.update { it.copy(isLoading = true, errorMessage = null) }
        viewModelScope.launch {
            try {
                repo.register(
                    fullName = state.fullName,
                    email = state.email,
                    username = state.username,
                    password = state.password,
                    gender = state.gender,
                    dateOfBirth = state.dateOfBirth.ifBlank { null },
                    countryCode = state.countryCode,
                )
                _registerState.update { it.copy(isLoading = false, successEvent = true) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _registerState.update {
                    it.copy(isLoading = false, errorMessage = e.message ?: "Registration failed.")
                }
            }
        }
    }

    fun consumeRegisterSuccess() {
        _registerState.update { it.copy(successEvent = false) }
    }

    // ── Forgot password ───────────────────────────────────────────────

    fun onForgotEmailChange(value: String) {
        _forgotState.update { it.copy(email = value, errorMessage = null) }
    }

    fun submitForgotPassword() {
        val state = _forgotState.value
        if (state.isLoading) return
        if (!TextUtils.isValidEmail(state.email)) {
            _forgotState.update { it.copy(errorMessage = "Please enter a valid email address.") }
            return
        }
        _forgotState.update { it.copy(isLoading = true, errorMessage = null) }
        viewModelScope.launch {
            try {
                repo.forgotPassword(state.email)
                _forgotState.update { it.copy(isLoading = false, successEvent = true) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _forgotState.update {
                    it.copy(isLoading = false, errorMessage = e.message ?: "Could not send reset email.")
                }
            }
        }
    }

    fun consumeForgotSuccess() {
        _forgotState.update { it.copy(successEvent = false) }
    }

    // ── Reset password ────────────────────────────────────────────────

    fun onResetPasswordChange(value: String) {
        _resetState.update { it.copy(password = value, errorMessage = null) }
    }

    fun onResetConfirmPasswordChange(value: String) {
        _resetState.update { it.copy(confirmPassword = value, errorMessage = null) }
    }

    fun submitResetPassword(token: String) {
        val state = _resetState.value
        if (state.isLoading) return
        if (state.password.length < 8) {
            _resetState.update { it.copy(errorMessage = "Password must be at least 8 characters.") }
            return
        }
        if (state.password != state.confirmPassword) {
            _resetState.update { it.copy(errorMessage = "Passwords do not match.") }
            return
        }
        _resetState.update { it.copy(isLoading = true, errorMessage = null) }
        viewModelScope.launch {
            try {
                repo.resetPassword(token, state.password)
                _resetState.update { it.copy(isLoading = false, successEvent = true) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _resetState.update {
                    it.copy(isLoading = false, errorMessage = e.message ?: "Could not reset password.")
                }
            }
        }
    }

    fun consumeResetSuccess() {
        _resetState.update { it.copy(successEvent = false) }
    }

    // ── Logout ────────────────────────────────────────────────────────

    fun logout(onComplete: () -> Unit) {
        viewModelScope.launch {
            try {
                repo.logout()
            } catch (_: Exception) {
                // Non-fatal — clearLocalSession() was called inside logout().
            }
            onComplete()
        }
    }
}
