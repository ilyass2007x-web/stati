package com.centrychat.android.feature.feed

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.centrychat.android.R
import com.centrychat.android.data.model.FeedItemDto
import com.centrychat.android.rememberFeedViewModel
import com.centrychat.android.ui.components.CentryChatAvatar
import com.centrychat.android.ui.components.EmptyState
import com.centrychat.android.ui.components.ErrorState
import com.centrychat.android.ui.components.VerifiedBadge
import com.centrychat.android.core.util.TextUtils
import com.centrychat.android.core.util.TimeFormatter

/**
 * The home feed screen.
 *
 * Renders the unified feed (posts + articles merged + ranked by the backend's
 * recommendation algorithm). The client does NOT re-rank — it renders items
 * in the order the backend returns them.
 *
 * Supports:
 *  - Pull-to-refresh (via [refresh] callback).
 *  - Infinite scroll (triggers [loadMore] when the user is near the end).
 *  - Empty state (when the user follows no one + has no interests).
 *  - Error state (when the network fails — provides a Retry button).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeedScreen(
    contentPadding: PaddingValues,
    onPostClick: (String) -> Unit,
    onArticleClick: (String) -> Unit,
    onUserClick: (String) -> Unit,
) {
    val viewModel = rememberFeedViewModel()
    val state by viewModel.state.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()

    // Trigger loadMore when the user scrolls near the end.
    val shouldLoadMore by remember {
        derivedStateOf {
            val lastVisibleIndex = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            val total = listState.layoutInfo.totalItemsCount
            total > 0 && lastVisibleIndex >= total - 3
        }
    }
    LaunchedEffect(shouldLoadMore) {
        if (shouldLoadMore) viewModel.loadMore()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(R.string.feed_title),
                        fontWeight = FontWeight.Bold,
                    )
                },
            )
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            when {
                state.isLoading && state.items.isEmpty() -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                state.error != null && state.items.isEmpty() -> {
                    ErrorState(
                        message = state.error!!,
                        onRetry = viewModel::refresh,
                    )
                }
                state.isEmpty -> {
                    EmptyState(message = stringResource(R.string.feed_empty))
                }
                else -> {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(state.items) { item ->
                            FeedItemRow(
                                item = item,
                                onPostClick = onPostClick,
                                onArticleClick = onArticleClick,
                                onUserClick = onUserClick,
                            )
                        }
                        if (state.isLoadingMore) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    CircularProgressIndicator()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FeedItemRow(
    item: FeedItemDto,
    onPostClick: (String) -> Unit,
    onArticleClick: (String) -> Unit,
    onUserClick: (String) -> Unit,
) {
    when {
        item.post != null -> PostCard(
            post = item.post,
            onClick = { onPostClick(item.post.id) },
            onUserClick = onUserClick,
        )
        item.article != null -> ArticleCard(
            article = item.article,
            onClick = { onArticleClick(item.article.id) },
            onUserClick = onUserClick,
        )
    }
}

@Composable
private fun PostCard(
    post: com.centrychat.android.data.model.PostDto,
    onClick: () -> Unit,
    onUserClick: (String) -> Unit,
) {
    androidx.compose.material3.Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp),
    ) {
        Column(Modifier.padding(16.dp)) {
            // Author row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth(),
            ) {
                CentryChatAvatar(
                    fullName = post.author.fullName,
                    avatarColor = post.author.avatarColor,
                    avatarUrl = post.author.avatarUrl,
                    onClick = { onUserClick(post.author.username) },
                    size = 40.dp,
                )
                Spacer(Modifier.size(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = post.author.fullName,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                        )
                        if (post.author.isVerified) {
                            Spacer(Modifier.size(4.dp))
                            VerifiedBadge()
                        }
                    }
                    Text(
                        text = "@${post.author.username} · ${TimeFormatter.relative(post.createdAt)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            // Content
            Text(
                text = post.content,
                style = MaterialTheme.typography.bodyLarge,
            )
            Spacer(Modifier.height(12.dp))
            // Engagement row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(24.dp),
            ) {
                EngagementCounter(
                    icon = Icons.Filled.FavoriteBorder,
                    count = post.likeCount,
                    active = post.isLiked,
                )
                EngagementCounter(
                    icon = Icons.Filled.ChatBubbleOutline,
                    count = post.commentCount,
                )
                EngagementCounter(
                    icon = Icons.Filled.Share,
                    count = post.shareCount,
                )
            }
        }
    }
}

@Composable
private fun ArticleCard(
    article: com.centrychat.android.data.model.ArticleCardDto,
    onClick: () -> Unit,
    onUserClick: (String) -> Unit,
) {
    androidx.compose.material3.Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.Article,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp),
                )
                Spacer(Modifier.size(8.dp))
                Text(
                    text = stringResource(R.string.articles_title),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = article.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            article.excerpt?.let {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = TextUtils.truncate(it, 200),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                CentryChatAvatar(
                    fullName = article.author.fullName,
                    avatarColor = article.author.avatarColor,
                    avatarUrl = article.author.avatarUrl,
                    onClick = { onUserClick(article.author.username) },
                    size = 24.dp,
                )
                Spacer(Modifier.size(8.dp))
                Text(
                    text = "@${article.author.username}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                article.readingTime?.let {
                    Spacer(Modifier.size(8.dp))
                    Text(
                        text = "· ${it}m",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun EngagementCounter(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    count: Long,
    active: Boolean = false,
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp),
        )
        Spacer(Modifier.size(4.dp))
        Text(
            text = TextUtils.compactCount(count),
            style = MaterialTheme.typography.bodySmall,
            color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
