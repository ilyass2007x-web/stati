package com.centrychat.android.feature.messaging

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.MessageDto
import com.centrychat.android.data.repository.MessagingRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Conversation detail ViewModel — loads messages for a single conversation
 * and polls every 15s for new messages (matches the web's MainNav
 * polling pattern). Real-time socket.io is tracked as a follow-up.
 */
class ConversationDetailViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: MessagingRepository = appContainer.messagingRepository

    private val _state = MutableStateFlow<UiState<List<MessageDto>>>(UiState.Loading)
    val state: StateFlow<UiState<List<MessageDto>>> = _state.asStateFlow()

    private val _sendError = MutableStateFlow<String?>(null)
    val sendError: StateFlow<String?> = _sendError.asStateFlow()

    private val _isSending = MutableStateFlow(false)
    val isSending: StateFlow<Boolean> = _isSending.asStateFlow()

    private var pollJob: kotlinx.coroutines.Job? = null
    private var conversationId: String = ""

    fun load(conversationId: String) {
        this.conversationId = conversationId
        _state.value = UiState.Loading
        viewModelScope.launch {
            try {
                val messages = repo.getMessages(conversationId)
                _state.value = if (messages.isEmpty()) UiState.Empty else UiState.Success(messages)
                // Mark the conversation as read — clears the unread badge.
                try { repo.markRead(conversationId) } catch (_: Exception) {}
                startPolling()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.value = UiState.Error(e.message ?: "Could not load messages.")
            }
        }
    }

    private fun startPolling() {
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            while (isActive) {
                delay(15_000L)
                try {
                    val messages = repo.getMessages(conversationId)
                    _state.value = if (messages.isEmpty()) UiState.Empty else UiState.Success(messages)
                    try { repo.markRead(conversationId) } catch (_: Exception) {}
                } catch (_: Exception) {
                    // Silent — polling failures are non-fatal
                }
            }
        }
    }

    fun sendMessage(content: String) {
        if (_isSending.value) return
        if (content.isBlank()) return
        _isSending.value = true
        _sendError.value = null
        viewModelScope.launch {
            try {
                val newMessage = repo.sendMessage(conversationId, content.trim())
                // Append to the current state — the next poll will reconcile.
                val current = (_state.value as? UiState.Success)?.data ?: emptyList()
                _state.value = UiState.Success(current + newMessage)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _sendError.value = e.message ?: "Could not send message."
            } finally {
                _isSending.value = false
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        pollJob?.cancel()
    }
}
