package com.centrychat.android.feature.messaging

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.ConversationDto
import com.centrychat.android.data.repository.MessagingRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Conversations list ViewModel — loads the user's conversations list and
 * polls every 15s for new messages (matches the web's MainNav polling
 * pattern for the unread-count badge).
 *
 * Real-time socket.io integration is tracked as a follow-up. For v1,
 * polling is acceptable: the user sees the latest conversations within
 * 15s of any change.
 */
class ConversationsViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: MessagingRepository = appContainer.messagingRepository

    private val _state = MutableStateFlow<UiState<List<ConversationDto>>>(UiState.Loading)
    val state: StateFlow<UiState<List<ConversationDto>>> = _state.asStateFlow()

    private var pollJob: kotlinx.coroutines.Job? = null

    fun load() {
        _state.value = UiState.Loading
        viewModelScope.launch {
            try {
                val list = repo.getConversations()
                _state.value = if (list.isEmpty()) UiState.Empty else UiState.Success(list)
                startPolling()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.value = UiState.Error(e.message ?: "Could not load conversations.")
            }
        }
    }

    private fun startPolling() {
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            while (isActive) {
                delay(15_000L)
                try {
                    val list = repo.getConversations()
                    _state.value = if (list.isEmpty()) UiState.Empty else UiState.Success(list)
                } catch (_: Exception) {
                    // Silent — polling failures are non-fatal
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        pollJob?.cancel()
    }
}
