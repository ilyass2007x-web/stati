package com.centrychat.android.feature.profile

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.centrychat.android.R
import com.centrychat.android.core.LocalAppContainer
import com.centrychat.android.core.util.TextUtils
import com.centrychat.android.core.util.TimeFormatter
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.ArticleCardDto
import com.centrychat.android.data.model.PlaylistDto
import com.centrychat.android.data.model.PostDto
import com.centrychat.android.data.model.UserProfileSummary
import com.centrychat.android.ui.components.CentryChatAvatar
import com.centrychat.android.ui.components.EmptyState
import com.centrychat.android.ui.components.ErrorState
import com.centrychat.android.ui.components.VerifiedBadge

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    contentPadding: PaddingValues? = null,
    username: String?,
    isOwnProfile: Boolean,
    onBack: (() -> Unit)? = null,
    onEditProfile: () -> Unit,
    onUserClick: (String) -> Unit,
    onPostClick: (String) -> Unit,
    onArticleClick: ((String) -> Unit)? = null,
    onPlaylistClick: ((String) -> Unit)? = null,
    onFollowersClick: (String) -> Unit,
    onFollowingClick: (String) -> Unit,
    onSettingsClick: () -> Unit,
    onMessageUser: ((userId: String, username: String) -> Unit)? = null,
) {
    val appContainer = LocalAppContainer.current
    val viewModel: ProfileViewModel = viewModel(
        factory = remember {
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T =
                    ProfileViewModel(appContainer) as T
            }
        }
    )

    val state by viewModel.profileState.collectAsStateWithLifecycle()
    val isFollowing by viewModel.isFollowing.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val feedState by viewModel.feed.collectAsStateWithLifecycle()
    val playlistsState by viewModel.playlists.collectAsStateWithLifecycle()

    LaunchedEffect(username) { viewModel.loadProfile(username) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(username?.let { "@$it" } ?: stringResource(R.string.nav_profile)) },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(onClick = onBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = stringResource(R.string.cd_back_button),
                            )
                        }
                    }
                },
                actions = {
                    if (isOwnProfile) {
                        IconButton(onClick = onSettingsClick) {
                            Icon(Icons.Filled.Settings, contentDescription = null)
                        }
                    } else {
                        IconButton(onClick = { viewModel.refresh() }) {
                            Icon(Icons.Filled.Refresh, contentDescription = null)
                        }
                    }
                },
            )
        },
    ) { padding ->
        Box(modifier = Modifier
            .fillMaxSize()
            .padding(padding)) {
            when (val s = state) {
                UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                is UiState.Error -> ErrorState(message = s.message, onRetry = { viewModel.loadProfile(username) })
                UiState.Empty -> EmptyState(message = "User not found.")
                is UiState.Success -> ProfileContent(
                    profile = s.data,
                    isOwnProfile = isOwnProfile,
                    isFollowing = isFollowing,
                    onToggleFollow = { viewModel.toggleFollow(s.data.username) },
                    onEditProfile = onEditProfile,
                    onFollowersClick = { onFollowersClick(s.data.username) },
                    onFollowingClick = { onFollowingClick(s.data.username) },
                    selectedTab = selectedTab,
                    onSelectTab = viewModel::selectTab,
                    feedState = feedState,
                    playlistsState = playlistsState,
                    onPostClick = onPostClick,
                    onArticleClick = onArticleClick,
                    onPlaylistClick = onPlaylistClick,
                    onUserClick = onUserClick,
                    onRetryPosts = { viewModel.loadProfile(username) },
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProfileContent(
    profile: UserProfileSummary,
    isOwnProfile: Boolean,
    isFollowing: Boolean,
    onToggleFollow: () -> Unit,
    onEditProfile: () -> Unit,
    onFollowersClick: () -> Unit,
    onFollowingClick: () -> Unit,
    selectedTab: ProfileTab,
    onSelectTab: (ProfileTab) -> Unit,
    feedState: UiState<List<ProfileFeedItem>>,
    playlistsState: UiState<List<PlaylistDto>>,
    onPostClick: (String) -> Unit,
    onArticleClick: ((String) -> Unit)?,
    onPlaylistClick: ((String) -> Unit)?,
    onUserClick: (String) -> Unit,
    onRetryPosts: () -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxSize(),
    ) {
        // ── Header (avatar, name, bio, stats, action button) ───────────
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CentryChatAvatar(
                    fullName = profile.fullName,
                    avatarColor = profile.avatarColor,
                    avatarUrl = profile.avatarUrl,
                    size = 80.dp,
                )
                Spacer(Modifier.size(16.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = profile.fullName,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                        )
                        if (profile.isVerified) {
                            Spacer(Modifier.size(6.dp))
                            VerifiedBadge()
                        }
                    }
                    Text(
                        text = "@${profile.username}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            if (!profile.bio.isNullOrBlank()) {
                Spacer(Modifier.height(12.dp))
                Text(text = profile.bio, style = MaterialTheme.typography.bodyMedium)
            }

            Spacer(Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(24.dp),
            ) {
                Statistic(
                    label = stringResource(R.string.profile_posts),
                    count = profile.postsCount,
                    onClick = {},
                )
                Statistic(
                    label = stringResource(R.string.profile_followers),
                    count = profile.followersCount,
                    onClick = onFollowersClick,
                )
                Statistic(
                    label = stringResource(R.string.profile_following),
                    count = profile.followingCount,
                    onClick = onFollowingClick,
                )
            }

            Spacer(Modifier.height(16.dp))

            if (isOwnProfile) {
                OutlinedButton(
                    onClick = onEditProfile,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(stringResource(R.string.profile_edit))
                }
            } else {
                FilledTonalButton(
                    onClick = onToggleFollow,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(if (isFollowing) stringResource(R.string.post_action_unfollow) else stringResource(R.string.post_action_follow))
                }
            }
        }

        // ── Tabs (Posts | Playlists) — matches the web's 2-tab layout ────
        // The web's Profile (src/components/profile/profile-screen.tsx)
        // has only TWO tabs: Posts + Playlists. The Posts tab merges short
        // Posts + long Articles in one list (Articles are NOT a separate
        // tab — they're a kind of content inside the Posts tab).
        TabRow(selectedTabIndex = selectedTab.ordinal) {
            val tabs = ProfileTab.entries
            tabs.forEach { tab ->
                Tab(
                    selected = selectedTab == tab,
                    onClick = { onSelectTab(tab) },
                    text = { Text(stringResource(tab.labelRes)) },
                )
            }
        }

        // ── Tab content (fills remaining space) ────────────────────────
        Box(modifier = Modifier.fillMaxSize().padding(top = 8.dp)) {
            when (selectedTab) {
                ProfileTab.POSTS -> TabContent(
                    state = feedState,
                    onRetry = onRetryPosts,
                    emptyMessage = "No posts yet.",
                ) { feed ->
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(feed, key = { it.id }) { item ->
                            when (item) {
                                is ProfileFeedItem.Post -> ProfilePostCard(
                                    post = item.post,
                                    onClick = { onPostClick(item.post.id) },
                                    onUserClick = onUserClick,
                                )
                                is ProfileFeedItem.Article -> ProfileArticleCard(
                                    article = item.article,
                                    onClick = { onArticleClick?.invoke(item.article.id) },
                                    onUserClick = onUserClick,
                                )
                            }
                        }
                    }
                }
                ProfileTab.PLAYLISTS -> TabContent(
                    state = playlistsState,
                    onRetry = onRetryPosts,
                    emptyMessage = "No playlists yet.",
                ) { playlists ->
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(playlists, key = { it.id }) { playlist ->
                            ProfilePlaylistCard(
                                playlist = playlist,
                                onClick = { onPlaylistClick?.invoke(playlist.id) },
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Wrapper that renders a Loading / Error / Empty / Success state for a
 * tab's data. The [content] lambda is only invoked when the state is
 * [UiState.Success] with a non-empty list.
 */
@Composable
private fun <T> TabContent(
    state: UiState<List<T>>,
    onRetry: () -> Unit,
    emptyMessage: String,
    content: @Composable (List<T>) -> Unit,
) {
    when (state) {
        is UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        is UiState.Error -> ErrorState(message = state.message, onRetry = onRetry)
        is UiState.Empty -> EmptyState(message = emptyMessage)
        is UiState.Success -> content(state.data)
    }
}

@Composable
private fun Statistic(label: String, count: Long, onClick: () -> Unit) {
    Column(
        modifier = Modifier.clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = TextUtils.compactCount(count),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun ProfilePostCard(
    post: PostDto,
    onClick: () -> Unit,
    onUserClick: (String) -> Unit,
) {
    androidx.compose.material3.Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth(),
            ) {
                CentryChatAvatar(
                    fullName = post.author.fullName,
                    avatarColor = post.author.avatarColor,
                    avatarUrl = post.author.avatarUrl,
                    onClick = { onUserClick(post.author.username) },
                    size = 40.dp,
                )
                Spacer(Modifier.size(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = post.author.fullName,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                        )
                        if (post.author.isVerified) {
                            Spacer(Modifier.size(4.dp))
                            VerifiedBadge()
                        }
                    }
                    Text(
                        text = "@${post.author.username} · ${TimeFormatter.relative(post.createdAt)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                text = post.content,
                style = MaterialTheme.typography.bodyLarge,
            )
            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(24.dp),
            ) {
                EngagementCounter(Icons.Filled.FavoriteBorder, post.likeCount, post.isLiked)
                EngagementCounter(Icons.Filled.ChatBubbleOutline, post.commentCount)
                EngagementCounter(Icons.Filled.Share, post.shareCount)
            }
        }
    }
}

@Composable
private fun ProfileArticleCard(
    article: ArticleCardDto,
    onClick: () -> Unit,
    onUserClick: (String) -> Unit,
) {
    androidx.compose.material3.Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.Article,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp),
                )
                Spacer(Modifier.size(8.dp))
                Text(
                    text = stringResource(R.string.articles_title),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = article.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            article.excerpt?.let {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = TextUtils.truncate(it, 200),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                CentryChatAvatar(
                    fullName = article.author.fullName,
                    avatarColor = article.author.avatarColor,
                    avatarUrl = article.author.avatarUrl,
                    onClick = { onUserClick(article.author.username) },
                    size = 24.dp,
                )
                Spacer(Modifier.size(8.dp))
                Text(
                    text = "@${article.author.username}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                article.readingTime?.let {
                    Spacer(Modifier.size(8.dp))
                    Text(
                        text = "· ${it}m",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun ProfilePlaylistCard(
    playlist: PlaylistDto,
    onClick: () -> Unit,
) {
    androidx.compose.material3.Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(playlist.name, style = MaterialTheme.typography.titleMedium)
            playlist.description?.let {
                Spacer(Modifier.height(4.dp))
                Text(it, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "${playlist.itemsCount} article(s)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline,
            )
        }
    }
}

@Composable
private fun EngagementCounter(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    count: Long,
    active: Boolean = false,
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp),
        )
        Spacer(Modifier.size(4.dp))
        Text(
            text = TextUtils.compactCount(count),
            style = MaterialTheme.typography.bodySmall,
            color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
