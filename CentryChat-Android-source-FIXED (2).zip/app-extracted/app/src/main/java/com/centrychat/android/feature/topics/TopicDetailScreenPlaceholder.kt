package com.centrychat.android.feature.topics

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

/**
 * Placeholder for the topic detail screen.
 *
 * The full implementation will reuse the Feed UI with the topic's content
 * feed (the backend's `/topics/{slug}/content` returns the same shape as
 * `/feed/unified`). For now, this placeholder shows a "coming soon" message
 * — the underlying API + repository are already wired up via
 * `TopicsRepository.getTopicContent(slug)`.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopicDetailScreenPlaceholder(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Topic") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        Box(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentAlignment = Alignment.Center,
        ) {
            Text("Topic detail screen — full content feed coming soon.")
        }
    }
}
