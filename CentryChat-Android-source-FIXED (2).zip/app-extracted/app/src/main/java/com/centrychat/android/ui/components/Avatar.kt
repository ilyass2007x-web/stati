package com.centrychat.android.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

/**
 * The CentryChat avatar — renders the user's uploaded image when present,
 * otherwise a colored circle with the user's initial.
 */
@Composable
fun CentryChatAvatar(
    fullName: String,
    avatarColor: String?,
    avatarUrl: String?,
    onClick: (() -> Unit)? = null,
    size: androidx.compose.ui.unit.Dp = 40.dp,
) {
    val baseModifier = Modifier
        .size(size)
        .clip(CircleShape)
        .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)

    if (!avatarUrl.isNullOrBlank()) {
        AsyncImage(
            model = avatarUrl,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = baseModifier,
        )
    } else {
        val color = parseColor(avatarColor) ?: hashColor(fullName)
        Box(
            modifier = baseModifier.background(color),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = fullName.firstOrNull()?.uppercase() ?: "?",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
            )
        }
    }
}

/**
 * The CentryChat verified badge — a small filled circle with a checkmark.
 */
@Composable
fun VerifiedBadge(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(16.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = Icons.Filled.Check,
            contentDescription = "Verified",
            tint = Color.White,
            modifier = Modifier.size(12.dp),
        )
    }
}

/**
 * A simple text-based user row (used in search results, followers lists).
 */
@Composable
fun UserRow(
    fullName: String,
    username: String,
    avatarColor: String?,
    avatarUrl: String?,
    isVerified: Boolean,
    bio: String?,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CentryChatAvatar(
            fullName = fullName,
            avatarColor = avatarColor,
            avatarUrl = avatarUrl,
            onClick = onClick,
            size = 44.dp,
        )
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = fullName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                )
                if (isVerified) {
                    Spacer(Modifier.size(4.dp))
                    VerifiedBadge()
                }
            }
            Text(
                text = "@$username",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (!bio.isNullOrBlank()) {
                Text(
                    text = bio,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
        }
    }
}

// ── Color helpers ────────────────────────────────────────────────────────

private fun parseColor(hex: String?): Color? {
    if (hex.isNullOrBlank()) return null
    val cleaned = hex.removePrefix("#")
    return try {
        val long = cleaned.toLong(16)
        when (cleaned.length) {
            6 -> Color(0xFF000000 or long)
            8 -> Color(long)
            else -> null
        }
    } catch (_: NumberFormatException) {
        null
    }
}

private fun hashColor(seed: String): Color {
    val palette = listOf(
        Color(0xFF1E5AF6),
        Color(0xFF22D3EE),
        Color(0xFF8E51FF),
        Color(0xFF16A34A),
        Color(0xFFDC2626),
        Color(0xFFF59E0B),
        Color(0xFFEC4899),
        Color(0xFF0EA5E9),
    )
    val hash = seed.fold(0) { acc, ch -> (acc * 31 + ch.code) and 0x7FFFFFFF }
    return palette[hash % palette.size]
}
