package com.centrychat.android.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.centrychat.android.R

/**
 * The blue verification badge — a small filled circle with a white checkmark.
 *
 * Mirrors the web's `VerifiedBadge` component (`src/components/shared/
 * verified-badge.tsx`).
 *
 * Used everywhere a user identity appears:
 *   - Feed post/article cards (author row)
 *   - Comments (comment author)
 *   - Profile header (next to the full name)
 *   - Search results (user rows)
 *   - Notifications (sender identity)
 *   - Messaging (conversation list + thread header)
 *
 * The `isVerified` flag comes from the backend's `SafeUser.isVerified`
 * field (admin-granted). The Android client NEVER sets this locally —
 * the server is the source of truth.
 */
@Composable
fun VerifiedBadge(
    modifier: Modifier = Modifier,
    size: Dp = 16.dp,
) {
    Box(
        modifier = modifier
            .size(size)
            .background(
                color = MaterialTheme.colorScheme.primary,
                shape = CircleShape,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = Icons.Filled.Check,
            contentDescription = stringResource(R.string.cd_verified_badge),
            tint = Color.White,
            modifier = Modifier.size(size * 0.65f),
        )
    }
}

/**
 * A reusable "profile identity row" — avatar + full name (with optional
 * verified badge) + @username.
 *
 * Renders the user identity in a CONSISTENT layout across the whole app:
 *
 *   [Avatar] Full Name ✓
 *            @username
 *
 * Used by:
 *   - FeedScreen's PostCard + ArticleCard (author row)
 *   - PostDetailScreen + ArticleDetailScreen (author row)
 *   - ProfileScreen (header)
 *   - SearchScreen (user result row)
 *   - NotificationsScreen (sender row)
 *   - MessagesScreen (conversation list + thread header)
 *
 * Why a single component: ensures that whenever the design changes
 * (e.g. avatar size, badge position, typography), all screens update
 * in lockstep — no drift between Feed / Profile / Search / etc.
 *
 * @param fullName   The user's full name (e.g. "Test User").
 * @param username   The user's @handle (without the @).
 * @param avatarColor  Hex color string for the fallback avatar.
 * @param avatarUrl    Optional uploaded avatar URL.
 * @param isVerified   Whether the user has the blue badge (server-granted).
 * @param onClick      Optional click handler (typically navigates to profile).
 * @param avatarSize   Avatar diameter (defaults to 40.dp; smaller for
 *                     compact contexts like comments).
 * @param nameStyle    Optional override for the full-name typography.
 * @param compact      If true, hides the @username line (used in tight
 *                     spaces like notification rows).
 */
@Composable
fun ProfileIdentityRow(
    fullName: String,
    username: String,
    avatarColor: String?,
    avatarUrl: String?,
    isVerified: Boolean,
    onClick: (() -> Unit)? = null,
    avatarSize: Dp = 40.dp,
    nameStyle: TextStyle = MaterialTheme.typography.bodyLarge,
    compact: Boolean = false,
    showUsername: Boolean = true,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = if (onClick != null) Modifier.clickable { onClick() } else Modifier,
    ) {
        CentryChatAvatar(
            fullName = fullName,
            avatarColor = avatarColor,
            avatarUrl = avatarUrl,
            onClick = onClick,
            size = avatarSize,
        )
        Spacer(Modifier.width(4.dp))
        Column(
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    text = fullName,
                    style = nameStyle,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                if (isVerified) {
                    VerifiedBadge(size = avatarSize * 0.4f)
                }
            }
            if (showUsername && !compact && username.isNotBlank()) {
                Text(
                    text = "@$username",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline,
                )
            }
        }
    }
}
